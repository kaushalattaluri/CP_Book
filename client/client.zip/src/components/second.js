import React from 'react';

const Second = ({filteredStudentsData}) => {
    return (
        <div>
            
        </div>
    );
} ;
export default Second;