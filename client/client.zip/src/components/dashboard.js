import React, { useState } from "react";
// import Form from "react-bootstrap/Form";
// import "../App.css";
import "../assets/img/apple-icon.png";
import "../assets/img/favicon.png";

import "../assets/css/nucleo-icons.css";
import "../assets/css/nucleo-svg.css";
import "https://kit.fontawesome.com/42d5adcbca.js";


import "../assets/css/soft-ui-dashboard.css";
import Mainpage from "./mainpage";
import Sidebar from "./sidebar";
// import "bootstrap/dist/css/bootstrap.min.css";

const Dashboard = () => {
    return (
        <div className="g-sidenav-show  bg-gray-100">
        <Sidebar />
        <Mainpage />
        </div>
    );
}

export default Dashboard;